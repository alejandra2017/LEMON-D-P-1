﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de DAO_catalogo
/// </summary>
public class DAO_catalogo
{
	public DAO_catalogo()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    public DataTable agregar_articulo(E_articulo articulo)
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("catalogo.f_agregar_articulo", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            dataAdapter.SelectCommand.Parameters.Add("_descripcion", NpgsqlDbType.Text).Value = articulo.Descripcion;
            dataAdapter.SelectCommand.Parameters.Add("_unidad_medida", NpgsqlDbType.Text).Value = articulo.Unidad_medida;
            dataAdapter.SelectCommand.Parameters.Add("_valor", NpgsqlDbType.Integer).Value = articulo.Valor;
            dataAdapter.SelectCommand.Parameters.Add("_dias", NpgsqlDbType.Integer).Value = articulo.Dias;
            dataAdapter.SelectCommand.Parameters.Add("_tipo_articulo", NpgsqlDbType.Integer).Value = articulo.Tipo_articulo;
            dataAdapter.SelectCommand.Parameters.Add("_session", NpgsqlDbType.Text).Value = articulo.Session;
            dataAdapter.SelectCommand.Parameters.Add("_modified_by", NpgsqlDbType.Text).Value = articulo.Modified_by;
            dataAdapter.SelectCommand.Parameters.Add("_otro", NpgsqlDbType.Text).Value = articulo.Otro;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
  public DataTable cargar_articulos(int tipo_articulo)
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("catalogo.f_cargar_articulos", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            dataAdapter.SelectCommand.Parameters.Add("_tipo_articulo", NpgsqlDbType.Integer).Value = tipo_articulo;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
    public DataTable eliminar_articulo(int id)
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("catalogo.f_eliminar_articulos", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            dataAdapter.SelectCommand.Parameters.Add("_id", NpgsqlDbType.Integer).Value = id;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
    public DataTable cargar_catalogo()
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("catalogo.f_cargar_categorias", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
    public DataTable cargar_categorias()
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("catalogo.f_cargar_filtro_categoria", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
    public DataTable cargar_categoria()
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("catalogo.f_cargar_categoria", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
    public DataTable modificar_articulo(E_articulo articulo)
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("catalogo.f_modificar_articulo", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            dataAdapter.SelectCommand.Parameters.Add("_id_articulo", NpgsqlDbType.Integer).Value = articulo.Id_articulo;
            dataAdapter.SelectCommand.Parameters.Add("_descripcion", NpgsqlDbType.Text).Value = articulo.Descripcion;
            dataAdapter.SelectCommand.Parameters.Add("_unidad_medida", NpgsqlDbType.Text).Value = articulo.Unidad_medida;
            dataAdapter.SelectCommand.Parameters.Add("_valor", NpgsqlDbType.Integer).Value = articulo.Valor;
            dataAdapter.SelectCommand.Parameters.Add("_dias", NpgsqlDbType.Integer).Value = articulo.Dias;
            dataAdapter.SelectCommand.Parameters.Add("_tipo_articulo", NpgsqlDbType.Integer).Value = articulo.Tipo_articulo;
            dataAdapter.SelectCommand.Parameters.Add("_session", NpgsqlDbType.Text).Value = articulo.Session;
            dataAdapter.SelectCommand.Parameters.Add("_modified_by", NpgsqlDbType.Text).Value = articulo.Modified_by;
            
            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
}