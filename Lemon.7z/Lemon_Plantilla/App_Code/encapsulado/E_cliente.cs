﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de E_cliente
/// </summary>
public class E_cliente
{
	public E_cliente()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    private int
        id_cliente;

    public int Id_cliente
    {
        get { return id_cliente; }
        set { id_cliente = value; }
    }
    private String
        nombre, apellido, direccion, telefono, razon_social, email, user_name, clave, session, modified_by;

    public String Modified_by
    {
        get { return modified_by; }
        set { modified_by = value; }
    }

    

    public String Session
    {
        get { return session; }
        set { session = value; }
    }

    public String Clave
    {
        get { return clave; }
        set { clave = value; }
    }

    public String User_name
    {
        get { return user_name; }
        set { user_name = value; }
    }

    public String Email
    {
        get { return email; }
        set { email = value; }
    }

    public String Razon_social
    {
        get { return razon_social; }
        set { razon_social = value; }
    }

    public String Telefono
    {
        get { return telefono; }
        set { telefono = value; }
    }

    public String Direccion
    {
        get { return direccion; }
        set { direccion = value; }
    }

    public String Apellido
    {
        get { return apellido; }
        set { apellido = value; }
    }

    public String Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }


}