﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class view_recuperar_contra : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
        {
            DAO_User user = new DAO_User();
            DataTable info = user.obtenerUsusarioToken(Request.QueryString[0]);

            if (int.Parse(info.Rows[0][0].ToString()) == -1)
                this.RegisterStartupScript("mensaje", "<script type='text/javascript'>alert('El Token es invalido. Genere uno nuevo');window.location=\"Loggin.aspx\"</script>");
            else if (int.Parse(info.Rows[0][0].ToString()) == -1)
                this.RegisterStartupScript("mensaje", "<script type='text/javascript'>alert('El Token esta vencido. Genere uno nuevo');window.location=\"Loggin.aspx\"</script>");
            else
                Session["user_id_token"] = int.Parse(info.Rows[0][0].ToString());
        }

        else
            Response.Redirect("~/view/Login.aspx");

    }
    protected void B_Cambiar_Click(object sender, EventArgs e)
    {
        DAO_User user = new DAO_User();
        EUsuario eUser = new EUsuario();

        eUser.Id_usuario = int.Parse(Session["user_id"].ToString());
        eUser.Clave = Tb_Contraseña.Text;

        user.actualziarContrasena(eUser);
        this.RegisterStartupScript("mensaje", "<script type='text/javascript'>alert('Su Contraseña ha sido actualizada.');window.location=\"Loggin.aspx\"</script>");

    }
}