﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modificar_Cliente : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        E_cliente datos_temp = new E_cliente();
        GridViewRow row = GridView1.Rows[e.RowIndex];
        DataTable validacion = new DataTable();
        
        if (int.Parse(((Label)row.FindControl("L_U_id")).Text) == id)
        {
            try
            {
                //encapsular datos 
                datos_temp.Id_cliente = int.Parse(((Label)row.FindControl("L_u_id")).Text);
                datos_temp.Nombre = ((TextBox)row.FindControl("TB_u_nombre")).Text;
                datos_temp.Apellido = ((TextBox)row.FindControl("TB_u_apellido")).Text;
                datos_temp.Razon_social = ((TextBox)row.FindControl("TB_u_razon_social")).Text;
                datos_temp.User_name = ((TextBox)row.FindControl("TB_u_alias")).Text;
                datos_temp.Telefono = ((TextBox)row.FindControl("TB_u_telefono")).Text;
                datos_temp.Direccion = ((TextBox)row.FindControl("TB_u_direccion")).Text;
                datos_temp.Email = ((TextBox)row.FindControl("TB_u_correo")).Text;
                datos_temp.Modified_by = (String)Session["user_id"];
                datos_temp.Session = (String)Session["session"];
                //invocar funcion
                DAO_cliente emple_U = new DAO_cliente();
                validacion=emple_U.modificar_cliente(datos_temp);
                DataRow fila = validacion.Rows[0];
                
                int io;
                int.TryParse(fila[0].ToString(), out io);
                if (io == 1)
                {
                    this.RegisterStartupScript("mensaje", "<script type='text/javascript'>alert('Registro Modificado');window.location=\"Modificar_Usuario.aspx\"</script>");
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "PopupScript", "alert('Registro Modificado');", true);
                    // ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Startup", "<script>showPopWin('Registro Modificado', null,'" + this.ID + "');</script>", true);
                }
                else
                {
                    this.RegisterStartupScript("mensaje", "<script type='text/javascript'>alert('Alias Ya Existente, Intente de nuevo');window.location=\"Modificar_Usuario.aspx\"</script>");
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "PopupScript", "alert('Alias Ya Existente, Imposible Modificar');", true);
                    //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Startup", "<script>showPopWin('Alias ya esxistente, Imposible Modificar', null,'" + this.ID + "');</script>", true);
                }

            }
            catch (System.NullReferenceException)
            {

            }
        }
        Response.Redirect("~/view/Modificar_Cliente.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        buscar_factura.Visible = false;
    }
}