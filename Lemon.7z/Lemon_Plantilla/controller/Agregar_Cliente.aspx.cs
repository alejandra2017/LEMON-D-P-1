﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Agregar_Cliente : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void B_guardar_Click(object sender, EventArgs e)
    {
        E_cliente datos_e = new E_cliente();
        DAO_cliente cliente = new DAO_cliente();
        DataTable vali = new DataTable();

        datos_e.Id_cliente = int.Parse(TB_id.Text);
        datos_e.Nombre = TB_nombre.Text;
        datos_e.Apellido = TB_apellido.Text;
        datos_e.User_name = TB_alias.Text;
        datos_e.Clave = TB_clave.Text;
        datos_e.Telefono = TB_telefono.Text;
        datos_e.Direccion = TB_direccion.Text;
        datos_e.Razon_social = TB_razon_social.Text;
        datos_e.Email = TB_email.Text;
        datos_e.Modified_by = (String)Session["user_id"];
        datos_e.Session = (String)Session["session"];



        vali = cliente.agregar_cliente(datos_e);
        DataRow row = vali.Rows[0];
        int validar;
        int.TryParse(row[0].ToString(),out validar);
        if (validar == 1)
        {
            L_validacion.Text = "Registro Cargado";
        }
        else
        {
            L_validacion.Text = "Id Repetido, Registro no cargado";
        }
        Response.Redirect("~/view/Agregar_Cliente.aspx");
    }
}