﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modificar_Articulo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GV_modificar_articulo_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int id = Convert.ToInt32(GV_modificar_articulo.DataKeys[e.RowIndex].Value);
        E_articulo datos_temp = new E_articulo();
        GridViewRow row = GV_modificar_articulo.Rows[e.RowIndex];
        DataTable validacion = new DataTable();

        if (int.Parse(((Label)row.FindControl("L_U_id")).Text) == id)
        {
            datos_temp.Id_articulo= int.Parse(((Label)row.FindControl("L_u_id")).Text);
            datos_temp.Descripcion = ((TextBox)row.FindControl("TB_u_descripcion")).Text;
            datos_temp.Valor = int.Parse(((TextBox)row.FindControl("TB_u_precio")).Text);
            datos_temp.Unidad_medida = ((TextBox)row.FindControl("TB_u_medida")).Text;
            datos_temp.Dias = int.Parse(((TextBox)row.FindControl("TB_u_dias")).Text);
            DropDownList lista=((DropDownList)row.FindControl("DDL_u_elemento"));
           
            datos_temp.Tipo_articulo = int.Parse(((DropDownList)row.FindControl("DDL_u_elemento")).SelectedValue);
            datos_temp.Modified_by = (String)Session["user_id"];
            datos_temp.Session = (String)Session["session"];

            DAO_catalogo catalogo = new DAO_catalogo();
            catalogo.modificar_articulo(datos_temp);
        }
        Response.Redirect("~/view/Modificar_Articulo.aspx");
    }
}