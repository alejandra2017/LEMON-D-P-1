﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Agregar_Usuario : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TB_clave_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        E_empleado datos = new E_empleado();
        DAO_Empleado empleado = new DAO_Empleado();
        
        datos.Nombre=TB_nombre.Text;
        datos.Apellido=TB_apellido.Text;
        datos.Alias=TB_alias.Text;
        datos.Clave=TB_clave.Text;
        datos.Telefono=TB_telefono.Text;
        datos.Direccion=TB_direccion.Text;
        datos.Email=TB_mail.Text;
        datos.Modified_by = (String)Session["user_id"];
        datos.Session_modi = (String)Session["session"];
        datos.Cargo = DDL_usuario.SelectedValue.ToString();

        empleado.agregar_usuario(datos);
        Response.Redirect("~/view/Agregar_Usuario.aspx");
    }
}