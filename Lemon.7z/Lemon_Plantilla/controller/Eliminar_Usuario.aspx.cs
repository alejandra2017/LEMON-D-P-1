﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Eliminar_Usuario : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GW_usuario_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        
        int id = Convert.ToInt32(GW_usuario.DataKeys[e.RowIndex].Value);
        E_empleado datos_temp = new E_empleado();
        DAO_Empleado empleado = new DAO_Empleado();
        datos_temp.Id_usuario = id;
        empleado.eliminar_empleados(datos_temp.Id_usuario);
        
        Response.Redirect("~/view/Eliminar_Usuario.aspx");
    }
    protected void buscar_factura0_Click(object sender, ImageClickEventArgs e)
    {

    }
}