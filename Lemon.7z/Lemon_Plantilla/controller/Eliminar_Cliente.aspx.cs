﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Eliminar_Cliente : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GV_eliminar_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int id = Convert.ToInt32(GV_eliminar.DataKeys[e.RowIndex].Value);
        E_empleado datos_temp = new E_empleado();
        DAO_cliente cliente = new DAO_cliente();
        datos_temp.Id_usuario = id;
        cliente.eliminar_cliente(datos_temp.Id_usuario);

        Response.Redirect("~/view/Eliminar_Cliente.aspx");
    }
}