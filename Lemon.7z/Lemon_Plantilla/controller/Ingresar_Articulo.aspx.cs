﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Ingresar_Articulo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TB_precio_TextChanged(object sender, EventArgs e)
    {
        
    }
    protected void B_guardar_Click(object sender, EventArgs e)
    {
        DAO_catalogo dao_c = new DAO_catalogo();
        E_articulo articulo = new E_articulo();

        articulo.Descripcion = TB_descripcion.Text;
        articulo.Unidad_medida = TB_medida.Text;
        articulo.Valor = int.Parse(TB_precio.Text);
        articulo.Dias = int.Parse(TB_dias.Text);
        articulo.Otro = "";
        articulo.Session = (String)Session["session"];
        articulo.Modified_by = (String)Session["user_id"];
        int valor = int.Parse(DDL_elemento.SelectedValue.ToString());
        if (int.Parse(DDL_elemento.SelectedValue.ToString()) == -1)
        {
            L_valiacion_categoria.Text = "Por favor elija una opcion valida";
        }
        else if (int.Parse(DDL_elemento.SelectedValue.ToString()) == 0)
        {
            articulo.Tipo_articulo = -2;
            articulo.Otro = TB_otros.Text;
            dao_c.agregar_articulo(articulo);
            L_valiacion_categoria.Text = "Articulo agregado";
        }
        else
        {
            articulo.Tipo_articulo = int.Parse(DDL_elemento.SelectedValue.ToString());
            dao_c.agregar_articulo(articulo);
            L_valiacion_categoria.Text = "Articulo agregado";
        }


    }
    protected void DDL_elemento_SelectedIndexChanged(object sender, EventArgs e)
    {
        int i = int.Parse(DDL_elemento.SelectedValue.ToString());
        if (int.Parse(DDL_elemento.SelectedValue.ToString()) == 0)
        {
            TB_otros.Enabled = true;
        }
        else
        {
            TB_otros.Enabled = false;
        }

    }
}