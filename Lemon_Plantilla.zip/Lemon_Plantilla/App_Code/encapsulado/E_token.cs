﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de E_token
/// </summary>
public class E_token
{
	public E_token()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    private Int32 id;

    public Int32 Id
    {
        get { return id; }
        set { id = value; }
    }
    private String nombre;

    public String Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }
    private String correo;

    public String Correo
    {
        get { return correo; }
        set { correo = value; }
    }
    private String user_name;

    public String User_name
    {
        get { return user_name; }
        set { user_name = value; }
    }
    private Int32 estado;

    public Int32 Estado
    {
        get { return estado; }
        set { estado = value; }
    }
    private long fecha;

    public long Fecha
    {
        get { return fecha; }
        set { fecha = value; }
    }
}