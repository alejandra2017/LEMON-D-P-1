﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de EUsuario
/// </summary>
public class EUsuario
{
	public EUsuario()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    private int id_usuario;

    public int Id_usuario
    {
        get { return id_usuario; }
        set { id_usuario = value; }
    }
    private string nombre;

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }
    private string apellido;

    public string Apellido
    {
        get { return apellido; }
        set { apellido = value; }
    }
    private string alias;

    public string Alias
    {
        get { return alias; }
        set { alias = value; }
    }
    private string clave;

    public string Clave
    {
        get { return clave; }
        set { clave = value; }
    }
    private string cargo;

    public string Cargo
    {
        get { return cargo; }
        set { cargo = value; }
    }
    private string telefono;

    public string Telefono
    {
        get { return telefono; }
        set { telefono = value; }
    }
    private string direccion;

    public string Direccion
    {
        get { return direccion; }
        set { direccion = value; }
    }
    private string email;

    public string Email
    {
        get { return email; }
        set { email = value; }
    }
    private string session;

    public string Session
    {
        get { return session; }
        set { session = value; }
    }
    private string modified_by;

    public string Modified_by
    {
        get { return modified_by; }
        set { modified_by = value; }
    }
    private string ip;

    public string Ip
    {
        get { return ip; }
        set { ip = value; }
    }
    private string mac;

    public string Mac
    {
        get { return mac; }
        set { mac = value; }
    }
}