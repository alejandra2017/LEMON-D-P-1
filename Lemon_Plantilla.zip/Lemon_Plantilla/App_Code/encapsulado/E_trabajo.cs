﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de E_trabajo
/// </summary>
public class E_trabajo
{
	public E_trabajo()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}

    private int id_trabajo, cantidad, id_cliente, id_etapa, id_usuario, id_factura, id_articulo, id_estado;

    public int Id_estado
    {
        get { return id_estado; }
        set { id_estado = value; }
    }

    public int Id_articulo
    {
        get { return id_articulo; }
        set { id_articulo = value; }
    }

    public int Id_factura
    {
        get { return id_factura; }
        set { id_factura = value; }
    }

    public int Id_usuario
    {
        get { return id_usuario; }
        set { id_usuario = value; }
    }

    public int Id_etapa
    {
        get { return id_etapa; }
        set { id_etapa = value; }
    }

    public int Id_cliente
    {
        get { return id_cliente; }
        set { id_cliente = value; }
    }

    public int Cantidad
    {
        get { return cantidad; }
        set { cantidad = value; }
    }

    public int Id_trabajo
    {
        get { return id_trabajo; }
        set { id_trabajo = value; }
    }
    private String descripcion, session, modified_by, ultima_fecha_modificacion;

    public String Ultima_fecha_modificacion
    {
        get { return ultima_fecha_modificacion; }
        set { ultima_fecha_modificacion = value; }
    }

    public String Modified_by
    {
        get { return modified_by; }
        set { modified_by = value; }
    }

    public String Session
    {
        get { return session; }
        set { session = value; }
    }

    public String Descripcion
    {
        get { return descripcion; }
        set { descripcion = value; }
    } 
}