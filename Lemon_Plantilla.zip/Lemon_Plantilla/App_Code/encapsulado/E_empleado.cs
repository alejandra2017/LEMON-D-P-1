﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de E_empleado
/// </summary>
public class E_empleado
{
	public E_empleado()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    private int id_usuario;

    public int Id_usuario
    {
        get { return id_usuario; }
        set { id_usuario = value; }
    }
    private String nombre,
            apellido,
            alias,
            clave,
            telefono,
            direccion,
            email,
            modified_by,
            session_modi,
            cargo;

    public String Cargo
    {
        get { return cargo; }
        set { cargo = value; }
    }

    public String Session_modi
    {
        get { return session_modi; }
        set { session_modi = value; }
    }

    public String Modified_by
    {
        get { return modified_by; }
        set { modified_by = value; }
    }

    public String Email
    {
        get { return email; }
        set { email = value; }
    }

    public String Direccion
    {
        get { return direccion; }
        set { direccion = value; }
    }

    public String Telefono
    {
        get { return telefono; }
        set { telefono = value; }
    }

    public String Clave
    {
        get { return clave; }
        set { clave = value; }
    }

    public String Alias
    {
        get { return alias; }
        set { alias = value; }
    }

    public String Apellido
    {
        get { return apellido; }
        set { apellido = value; }
    }

    public String Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }
}