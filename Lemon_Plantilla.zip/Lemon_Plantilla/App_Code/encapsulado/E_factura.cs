﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de E_factura
/// </summary>
public class E_factura
{
	public E_factura()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    private int id_factura, id_estado;

    public int Id_estado
    {
        get { return id_estado; }
        set { id_estado = value; }
    }

    public int Id_factura
    {
        get { return id_factura; }
        set { id_factura = value; }
    }
    private double sub_total, iva, total;

    public double Total
    {
        get { return total; }
        set { total = value; }
    }

    public double Iva
    {
        get { return iva; }
        set { iva = value; }
    }

    public double Sub_total
    {
        get { return sub_total; }
        set { sub_total = value; }
    }
    private String fecha_factura, session, modified_by;

    public String Modified_by
    {
        get { return modified_by; }
        set { modified_by = value; }
    }

    public String Session
    {
        get { return session; }
        set { session = value; }
    }

    public String Fecha_factura
    {
        get { return fecha_factura; }
        set { fecha_factura = value; }
    }
}