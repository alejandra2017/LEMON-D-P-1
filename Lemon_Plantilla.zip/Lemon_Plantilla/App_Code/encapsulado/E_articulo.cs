﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de E_articulo
/// </summary>
public class E_articulo
{
	public E_articulo()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    private int valor, id_articulo, dias, tipo_articulo;

    public int Tipo_articulo
    {
        get { return tipo_articulo; }
        set { tipo_articulo = value; }
    }

    public int Dias
    {
        get { return dias; }
        set { dias = value; }
    }

    public int Valor
    {
        get { return valor; }
        set { valor = value; }
    }

    public int Id_articulo
    {
        get { return id_articulo; }
        set { id_articulo = value; }
    }
    private String descripcion, session, modified_by, fecha_ultima_mod, unidad_medida, otro;

    public String Otro
    {
        get { return otro; }
        set { otro = value; }
    }

    public String Unidad_medida
    {
        get { return unidad_medida; }
        set { unidad_medida = value; }
    }

    public String Fecha_ultima_mod
    {
        get { return fecha_ultima_mod; }
        set { fecha_ultima_mod = value; }
    }

    public String Modified_by
    {
        get { return modified_by; }
        set { modified_by = value; }
    }

    public String Session
    {
        get { return session; }
        set { session = value; }
    }

    public String Descripcion
    {
        get { return descripcion; }
        set { descripcion = value; }
    }

}