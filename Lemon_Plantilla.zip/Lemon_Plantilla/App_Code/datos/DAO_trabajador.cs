﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de DAO_trabajador
/// </summary>
public class DAO_trabajador
{
	public DAO_trabajador()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    public DataTable agregar_trabajo(E_trabajo trabajo)
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("trabajo.f_agregar_trabajo", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            dataAdapter.SelectCommand.Parameters.Add("_descripcion", NpgsqlDbType.Text).Value = trabajo.Descripcion;
            dataAdapter.SelectCommand.Parameters.Add("_cantidad", NpgsqlDbType.Integer).Value = trabajo.Cantidad;
            dataAdapter.SelectCommand.Parameters.Add("_id_cliente", NpgsqlDbType.Integer).Value = trabajo.Id_cliente;
            dataAdapter.SelectCommand.Parameters.Add("_id_estado", NpgsqlDbType.Integer).Value = trabajo.Id_estado;
            dataAdapter.SelectCommand.Parameters.Add("_id_etapa", NpgsqlDbType.Integer).Value = trabajo.Id_etapa;
            dataAdapter.SelectCommand.Parameters.Add("_id_usuario", NpgsqlDbType.Integer).Value = trabajo.Id_usuario;
            dataAdapter.SelectCommand.Parameters.Add("_id_factura", NpgsqlDbType.Integer).Value = trabajo.Id_factura;
            dataAdapter.SelectCommand.Parameters.Add("_id_articulo", NpgsqlDbType.Integer).Value = trabajo.Id_articulo;
            dataAdapter.SelectCommand.Parameters.Add("_session", NpgsqlDbType.Text).Value = trabajo.Session;
            dataAdapter.SelectCommand.Parameters.Add("_modified_by", NpgsqlDbType.Varchar).Value = trabajo.Modified_by;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
    public DataTable cargar_trabajo(String nombre_cliente, DateTime fecha_inicio, DateTime fecha_final )
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("trabajo.f_cargar_trabajo", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            dataAdapter.SelectCommand.Parameters.Add("_nombre_cliente", NpgsqlDbType.Text).Value = nombre_cliente;
            dataAdapter.SelectCommand.Parameters.Add("_fecha_inicio", NpgsqlDbType.Timestamp).Value = fecha_inicio;
            dataAdapter.SelectCommand.Parameters.Add("_fecha_final", NpgsqlDbType.Timestamp).Value = fecha_final;

            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
}