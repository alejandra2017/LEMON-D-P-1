﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de DAO_facturacio
/// </summary>
public class DAO_facturacio
{
	public DAO_facturacio()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
    public DataTable facturar(E_factura factura)
    {
        DataTable Usuario = new DataTable();
        NpgsqlConnection conection = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["Postgres"].ConnectionString);

        try
        {
            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter("facturacion.facturar", conection);
            dataAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            dataAdapter.SelectCommand.Parameters.Add("_sub_total", NpgsqlDbType.Double).Value = factura.Sub_total;
            dataAdapter.SelectCommand.Parameters.Add("_iva", NpgsqlDbType.Double).Value = factura.Iva;
            dataAdapter.SelectCommand.Parameters.Add("_total", NpgsqlDbType.Double).Value = factura.Total;
            dataAdapter.SelectCommand.Parameters.Add("_session", NpgsqlDbType.Varchar).Value = factura.Session;
            dataAdapter.SelectCommand.Parameters.Add("_modified_by", NpgsqlDbType.Varchar).Value = factura.Modified_by;
            dataAdapter.SelectCommand.Parameters.Add("_id_estado", NpgsqlDbType.Integer).Value = factura.Id_estado;
            
            conection.Open();
            dataAdapter.Fill(Usuario);
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
        finally
        {
            if (conection != null)
            {
                conection.Close();
            }
        }
        return Usuario;
    }
}