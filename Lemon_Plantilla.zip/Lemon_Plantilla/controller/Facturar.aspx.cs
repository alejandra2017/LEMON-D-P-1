﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Facturar : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        L_nombre_vendedor.Text = (String)Session["user_id"];

    }
    protected void TB_id_cliente_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        E_factura factura= new E_factura();
        DAO_facturacio dao_factura = new DAO_facturacio();
        DataTable DT_id_cliente = new DataTable();

        GridViewRow row_cliente = GridView1.Rows[0];
        int id_factura = 0;
        if(Session["id_cliente"]!=null)
        {
            factura.Sub_total=double.Parse( L_sub_total.Text);
            factura.Iva= double.Parse(L_iva.Text);
            factura.Total= double.Parse(L_Total.Text);
            factura.Modified_by = (String)Session["user_id"];
            factura.Session= (String)Session["session"];
            factura.Id_estado = 2;
            DT_id_cliente= dao_factura.facturar(factura);
            DataRow fila= DT_id_cliente.Rows[0];
            
            int.TryParse(fila[0].ToString(), out id_factura);
            
        }
        
        int[] cant = new int[GridView1.Rows.Count];
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];

            bool isChecked = ((CheckBox)row.FindControl("CB_agregar_articulo")).Checked;
            int id_trabajador=0;
            int.TryParse(((DropDownList)row.FindControl("DDL_trabajador")).SelectedValue, out id_trabajador);
            if (isChecked && ((TextBox)row.FindControl("TB_cantidad_articulo")).Text!="" && id_trabajador!=0)
            {
                E_trabajo trabajo = new E_trabajo();
                trabajo.Descripcion= ((Label)row.FindControl("L_descripcion")).Text;
                trabajo.Cantidad=int.Parse(((TextBox)row.FindControl("TB_cantidad_articulo")).Text);
                trabajo.Id_cliente=(int)Session["id_cliente"];
                trabajo.Id_etapa=1;
                trabajo.Id_estado = 1;
                trabajo.Id_usuario=int.Parse(((DropDownList)row.FindControl("DDL_trabajador")).SelectedValue);
                trabajo.Id_factura= id_factura;
                trabajo.Id_articulo=int.Parse(((Label)row.FindControl("L_id_articulo")).Text);
                trabajo.Modified_by = (String)Session["user_id"];
                trabajo.Session = (String)Session["session"];
                
                DAO_trabajador dao_trabajo= new DAO_trabajador();
                dao_trabajo.agregar_trabajo(trabajo);
                Response.Redirect("~/view/facturacion_alert.aspx");
            }
            else
            {
                
            }
            
        }
    }

    protected void GV_eliminar_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        int id = Convert.ToInt32(GV_eliminar.DataKeys[e.NewSelectedIndex].Value);
        E_articulo datos_temp = new E_articulo();
        GridViewRow row = GV_eliminar.Rows[e.NewSelectedIndex];
        Session["id_cliente"]=id;
    }

    protected void CB_agregar_articulo_CheckedChanged(object sender, EventArgs e)
    {
        int[] cant = new int[GridView1.Rows.Count];
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];

            bool isChecked = ((CheckBox)row.FindControl("CB_agregar_articulo")).Checked;
            if (isChecked)
            {
                ((TextBox)row.FindControl("TB_cantidad_articulo")).Enabled = true;
                ((DropDownList)row.FindControl("DDL_trabajador")).Enabled = true;
            }
            else
            {
                ((TextBox)row.FindControl("TB_cantidad_articulo")).Enabled = false;
                ((DropDownList)row.FindControl("DDL_trabajador")).Enabled = false;
                ((TextBox)row.FindControl("TB_cantidad_articulo")).Text = "";
            }
        }
    }
    protected void TB_cantidad_articulo_TextChanged(object sender, EventArgs e)
    {
        double sumatoria = 0;
        int dias=0;
        int[] cant = new int[GridView1.Rows.Count];
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];
            int cantidad, valor,dia_articulo;
            int.TryParse(((TextBox)row.FindControl("TB_cantidad_articulo")).Text,out cantidad);
            int.TryParse(((Label)row.FindControl("L_valor")).Text, out valor);
            int.TryParse(((Label)row.FindControl("L_dias")).Text, out dia_articulo);

            if (cantidad > 0)
            {
                dias = dias + dia_articulo;
                sumatoria = sumatoria + (cantidad * valor);
            }
            else
            {

                ((TextBox)row.FindControl("TB_cantidad_articulo")).Text="";
                ((Label)row.FindControl("L_restriccion")).Visible = true;

            }
        }

        double iva = sumatoria * 0.19;
        double subtotal = sumatoria - iva;

        L_dias.Text = dias.ToString(); 
        L_sub_total.Text= subtotal.ToString();
        L_iva.Text = iva.ToString();
        L_Total.Text = sumatoria.ToString();

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int[] cant = new int[GridView1.Rows.Count];
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];
            int id_trabajador=0;
            int.TryParse(((DropDownList)row.FindControl("DDL_trabajador")).SelectedValue, out id_trabajador);
            if(id_trabajador==0)
            {
                ((Label)row.FindControl("L_restriccion_trabajador")).Visible = true;
            }
        }

    }


    protected void B_agregar_cliente_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/view/Agregar_cliente");
    }
}