﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Buscar_Trabajo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void C_inico_rango_SelectionChanged(object sender, EventArgs e)
    {
        
    }

    protected void C_inico_rango_DayRender(object sender, DayRenderEventArgs e)
    {
        
    }
    protected void C_final_rango_DayRender(object sender, DayRenderEventArgs e)
    {
        DateTime now = DateTime.Today;
        if (e.Day.Date.AddDays(-1) < now.Date)
        {
            e.Day.IsSelectable = true;
        }
        else
        {
            e.Day.IsSelectable = false;
        }
    }
    protected void B_guardar_Click(object sender, EventArgs e)
    {
        //configurar formulario
        TB_nombre.Visible = false;
        L_e_nombre.Visible = false;
        L_e_inicial.Visible = false;
        C_inico_rango.Visible = false;
        L_e_final.Visible = false;
        C_final_rango.Visible = false;
        GV_busqueda_trabajo.Visible = true;
        B_buscar.Visible = false;
        B_regresar.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TB_nombre.Visible = true;
        L_e_nombre.Visible = true;
        L_e_inicial.Visible = true;
        C_inico_rango.Visible = true;
        L_e_final.Visible = true;
        C_final_rango.Visible = true;
        GV_busqueda_trabajo.Visible = false;
        B_buscar.Visible = true;
        B_regresar.Visible = false;
    }
}