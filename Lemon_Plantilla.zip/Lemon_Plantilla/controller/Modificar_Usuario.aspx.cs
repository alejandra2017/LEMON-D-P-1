﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Npgsql;
using NpgsqlTypes;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class Modificar_Usuario : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void RE_metodo_gridview1(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
    {
        buscar_usuario.Visible = false;
    }

    protected void GridView1_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
    {
        int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        DataTable validacion = new DataTable();
        
        E_empleado datos_temp = new E_empleado();
        for (int i = 0; i < GridView1.Rows.Count; i++){
            GridViewRow row = GridView1.Rows[i];
            Label l_u_id = new Label();
            String prueba = ((Label)row.FindControl("L_U_id")).Text;
            if (int.Parse(((Label)row.FindControl("L_U_id")).Text) == id)
            {
                try
                {
                    //encapsular datos 
                        datos_temp.Id_usuario = int.Parse(((Label)row.FindControl("L_U_id")).Text);
                        datos_temp.Nombre = ((TextBox)row.FindControl("TB_nombre")).Text;
                        datos_temp.Apellido = ((TextBox)row.FindControl("TB_apellido")).Text;
                        datos_temp.Alias = ((TextBox)row.FindControl("TB_alias")).Text;
                        datos_temp.Clave = ((TextBox)row.FindControl("TB_clave")).Text;
                        datos_temp.Telefono = ((TextBox)row.FindControl("TB_telefono")).Text;
                        datos_temp.Direccion = ((TextBox)row.FindControl("TB_direccion")).Text;
                        datos_temp.Email = ((TextBox)row.FindControl("TB_mail")).Text;
                        datos_temp.Cargo = ((DropDownList)row.FindControl("DDL_usuario")).SelectedValue.ToString();
                        datos_temp.Modified_by = (String)Session["user_id"];
                        datos_temp.Session_modi = (String)Session["session"];
                    //invocar funcion
                        DAO_Empleado emple_U = new DAO_Empleado();
                        validacion= emple_U.update_empleados(datos_temp);
                        
                        DataRow fila = validacion.Rows[0];
                        int io; 
                        int.TryParse(fila[0].ToString(),out io);
                        if (io == 1)
                        {
                            RegisterClientScriptBlock("mensaje", "<script type='text/javascript'>alert('Registro Modificado');</script>");
                           //this.RegisterStartupScript("mensaje", "<script type='text/javascript'>alert('Registro Modificado');window.location=\"Modificar_Usuario.aspx\"</script>");
                           //Page.ClientScript.RegisterStartupScript(this.GetType(), "PopupScript", "alert('Registro Modificado');", true);
                           // ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Startup", "<script>showPopWin('Registro Modificado', null,'" + this.ID + "');</script>", true);
                        }
                        else
                        {
                            RegisterClientScriptBlock("mensaje", "<script type='text/javascript'>alert('Alias Ya Existente, Intente de nuevo');</script>");
                            //this.RegisterStartupScript("mensaje", "<script type='text/javascript'>alert('Alias Ya Existente, Intente de nuevo');window.location=\"Modificar_Usuario.aspx\"</script>");
                            //Page.ClientScript.RegisterStartupScript(this.GetType(), "PopupScript", "alert('Alias Ya Existente, Imposible Modificar');", true);
                            //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "Startup", "<script>showPopWin('Alias ya esxistente, Imposible Modificar', null,'" + this.ID + "');</script>", true);
                        }

                }
                catch (System.NullReferenceException)
                {

                }
            }
    }
        Response.Redirect("~/view/Modificar_Usuario.aspx");
    }
    protected void RU_metodo_gridview(object sender, GridViewUpdatedEventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ODS_empleado_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
    {

    }
}