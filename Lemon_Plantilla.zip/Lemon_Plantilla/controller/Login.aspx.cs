﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void entrar_Click(object sender, EventArgs e)
    {
        string user_nombre = TB_Nombre.Text;
        string password = TB_Password.Text;

        DAO_User datos = new DAO_User();
        DataTable data = datos.loggin(user_nombre, password);
        if (int.Parse(data.Rows[0]["user_id"].ToString()) > 0)
        {
            Session["nombre"] = data.Rows[0]["nombre"].ToString();
            Session["user_id"] = data.Rows[0]["user_id"].ToString();
            

            EUsuario datosUsuario = new EUsuario();
            MAC datos_cp = new MAC();
            datosUsuario.Id_usuario = int.Parse(Session["user_id"].ToString());
            datosUsuario.Ip = datos_cp.ip();
            datosUsuario.Mac = datos_cp.mac();
            datosUsuario.Session = Session.SessionID;
            Session["session"] = datosUsuario.Session; 

            datos.guardadoSession(datosUsuario);

            Response.Redirect("~/view/Principal.aspx");
        }
    }
    protected void LB_recuperar_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/view/New_contra.aspx");

    }
}